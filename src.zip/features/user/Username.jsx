function Username() {
  return <div className="hidden text-sm font-semibold md:block">Raymond</div>;
}

export default Username;
